jQuery.sap.includeScript("https://maps.googleapis.com/maps/api/js?sensor=false&libraries=places&language=es", 'google');
jQuery.sap.require("zpmfiolistord02/lipigas/zpmfiolistord02/js/moment");

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"zpmfiolistord02/lipigas/zpmfiolistord02/model/formatter",
	'sap/ui/model/Filter',
	'sap/m/TablePersoController',
	'zpmfiolistord02/lipigas/zpmfiolistord02/controller/DemoPersoService',
	'sap/m/MessageBox',
	'sap/m/Button',
	'sap/m/Dialog',
	'sap/m/Text',
	'sap/m/BusyDialog',
	"sap/m/Token",
	'sap/m/Tokenizer'
], function (Controller, JSONModel, formatter, Filter, TablePersoController, DemoPersoService, MessageBox, Button, Dialog, Text,
	BusyDialog, Token, Tokenizer) {
	"use strict";

	return Controller.extend("zpmfiolistord02.lipigas.zpmfiolistord02.controller.inicio", {

		formatter: formatter,

		oFormatYyyymmdd: null,

		_oFacetFilter: null,
		_oCalendarFilter: null,

		oFiltroGlobal: [],

		oFiltroLista: null,
		oFiltroFecha: null,
		oFiltroOrden: null,

		oTPerso: null,

		oVar: null,

		oExpand: false,

		oMarkerSin: [],

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function () {
			var oTable = this.byId("table");
			var that = this;

		},

		onAfterRendering: function () {
			this.lecturaUSER();
			this.oFormatYyyymmdd = sap.ui.core.format.DateFormat.getInstance({
				pattern: "yyyy-MM-dd"
			});

			var element = $("#homeBtn");

			function myFunction() {
				sessionStorage.clear();
			};

			element.onclick = myFunction; // Assigned
			this.feedTablePersonalization();
			this.getView().byId("oCantidadText").setText("");

		},

		onUpdateFinished: function (oEvent) {
			console.log("UPDATE FINISHED");
		},

		lecturaUSER: function () {
			var that = this;
			this.setBusyById("page", true);

			var method = "USUARIOS_FIORI";

			var item = {
				"tipo_proceso": "1",
				"nombreapp": "INSTALACIONES",
				"usuario": ""
			};
			//var username = sap.ushell.Container.getUser().getId();
			var filterArray = [];
			var Tec = "",
				Coord = "",
				Progra = "",
				Plani = "";

			that.getView().byId("oUserNameText").setText('');
			var fnVarSuccess = function (oData, response) {

				var dataItems = "";
				for (var i = 0; i < oData.results.length; i++) {
					dataItems = dataItems + oData.results[i].Item;
				}
				if (dataItems.length < 10 && dataItems.length >= 0) {
					dataItems = "[]";
				}
				var data = JSON.parse(dataItems);
				var userjSON = JSON.parse(data.USUARIOS);
				if (sessionStorage.user !== undefined) {

					var loguedUserBefore = JSON.parse(sessionStorage.user);
					var oFilterUser = new sap.ui.model.Filter({
						path: "IUname",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: loguedUserBefore.user
					});
					that.getView().byId("oUserNameText").setText(loguedUserBefore.user);

					filterArray.push(oFilterUser);
					if (sessionStorage.search !== undefined) {
						var searchValues = JSON.parse(sessionStorage.search);
						that.getView().byId("__picker0").setValue(searchValues.date1);
						that.getView().byId("__picker1").setValue(searchValues.date2);
						that.feedObjectStatus3();
						that.feedObjectStatus2();
						that.changeDate(filterArray);
						that.setBusyById("page", false);
						return true;
					}
					that.feedObjectStatus3();
					that.feedObjectStatus2();
					that.lectura(filterArray);
					that.setBusyById("page", false);
					return true;
				}

				var oSubDialog = new sap.m.Dialog({
					title: "Login",
					modal: true,
					type: "Standard",
					contentWidth: "35%"

				});
				oSubDialog.addContent(
					new sap.m.Panel({
						width: "100%",
						content: [
							new sap.m.Text({
								text: "User",
								width: '100%'
							}),
							new sap.m.Input({
								liveChange: function (oEvent) {
									var texto = oEvent.getParameters().value;
									oEvent.getSource().setValue(texto.toUpperCase());
								}
							})

						]
					})
				);
				oSubDialog.addContent(
					new sap.m.Panel({
						width: "100%",
						content: [
							new sap.m.Text({
								text: "Password",
								width: '100%'
							}),
							new sap.m.Input({
								type: "Password",
								liveChange: function (oEvent) {
									var texto = oEvent.getParameters().value;
									oEvent.getSource().setValue(texto.toUpperCase());
								}
							})

						]
					})
				);
				oSubDialog.addButton(
					new sap.m.Button({
						text: "Cancelar",
						type: "Reject",
						press: function () {
							oSubDialog.destroy();
							history.go(-1);
						}
					})
				);

				oSubDialog.addButton(
					new sap.m.Button({
						text: "Login",
						press: function () {
							var user, pass;
							var userObject, passObject;
							var paneles = this.getParent().getParent();
							var userData = paneles.mAggregations.content[0].mAggregations.content;
							var passwordData = paneles.mAggregations.content[1].mAggregations.content; 
							
							for (var o = 0; o < userData.length; o++) {
								if (((userData[o].getId()).includes("input")) == true) {
									userObject = sap.ui.getCore().byId(userData[o].getId());
									user = userObject.getValue();
								}
							}

							for (var u = 0; u < passwordData.length; u++) {
								if (((passwordData[u].getId()).includes("input")) == true) {
									passObject = sap.ui.getCore().byId(passwordData[u].getId());
									pass = passObject.getValue();
								}
							}

							var logued = that.checkLocalLogin(user, pass, userjSON);
							that.setParamModel(user, userjSON);
							if (logued == true) {
								var username = user;
								oSubDialog.destroy();
								var loguedJson = {
									user: user,
									password: pass
								};
								sessionStorage.setItem("user", JSON.stringify(loguedJson));
								that.getView().byId("oUserNameText").setText(user);

								var oFilterUser = new sap.ui.model.Filter({
									path: "IUname",
									operator: sap.ui.model.FilterOperator.EQ,
									value1: username
								});

								filterArray.push(oFilterUser);
								that.feedObjectStatus3();
								that.feedObjectStatus2();
								that.lectura(filterArray);
							} else {
								sap.m.MessageToast.show("Usuario o Password incorecto");
								userObject.setValue("")
								passObject.setValue("")
							}

						}
					})
				);

				oSubDialog.open();
			};

			var fnVarError = function (err) {
				sap.m.MessageToast.show("Ocurrió un problema en la comunicación con el servidor");
				that.setBusyById("page", false);
			};

			var object = {
				"userid": "",
				"method": method,
				"item": JSON.stringify(item)
			};

			that.onCallReadOdataUSER(object, fnVarSuccess, fnVarError);

		},

		checkLocalLogin: function (user, pass, json) {
			var flag = false;
			for (var i = 0; i < json.length; i++) {
				if (json[i].USUARIO == user) {
					if (json[i].CONTRASENA == pass) {
						flag = true;
						break;
					} else {
						flag = false
					}
				} else {
					flag = false
				}
			}
			return flag;

		},

		setParamModel: function (user, json) {
			var oModelUsers = new sap.ui.model.json.JSONModel();
			var jsonforusers = [];
			for (var o = 0; o < json.length; o++) {
				if (json[o].TECNICO == 'X') {
					var localjsonforusers = {
						"Bname": json[o].USUARIO,
						"NameText": json[o].NOMBREUS
					}
					jsonforusers.push(localjsonforusers);
				}

			}
			oModelUsers.setData(jsonforusers);
			sap.ui.getCore().setModel(oModelUsers, "oModelUsers");
			for (var i = 0; i < json.length; i++) {
				if (json[i].USUARIO == user) {
					var jsonparam = {
						"user": json[i].USUARIO,
						"tec": json[i].TECNICO,
						"cord": json[i].CORDINADOR,
						"progra": json[i].PROGRAMADR,
						"plani": json[i].PLANIFICAD
					}
					var oModelParamUser = new sap.ui.model.json.JSONModel();
					oModelParamUser.setData(jsonparam);
					sap.ui.getCore().setModel(oModelParamUser, "oModelParamUser");
					break;
				}
			}
		},

		lectura: function (filterArray) {
			var that = this;
			this.setBusyById("page", true);

			var arrayDATA = [];
			var lista1 = that.getView().byId("lista1");
			var lista2 = that.getView().byId("lista2");

			var fnVarSuccess = function (oData, response) {
				if (oData.results.length == 0) {
					sap.m.MessageToast.show("No se a encontrado ordenes de mantenimiento...");
					that.getView().byId("oCantidadText").setText('');
					that.setBusyById("page", false);
					lista1.setModel(null);
					lista2.setModel(null);
					return false;
				}
				for (var i = 0; i < oData.results.length; i++) {
					arrayDATA.push(oData.results[i]);
				}
				that.setBusyById("page", false);
				lista1.setModel(null);
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData(arrayDATA);
				lista1.setModel(oModel);
				lista2.setModel(oModel);
				that.feedFacetFilter(arrayDATA);
				that.getView().byId("oCantidadText").setText(oData.results.length);
				if (sessionStorage.search !== undefined) {
					var searchValues = JSON.parse(sessionStorage.search);
					that.getView().byId("multiInput1").setValue(searchValues.searchfield);
					that.filtrarOT();
				}
			};

			var fnVarError = function (err) {
				sap.m.MessageToast.show("Ocurrió un problema en la comunicación con el servidor");
				that.setBusyById("page", false);
			};

			that.onCallReadOdata(filterArray, fnVarSuccess, fnVarError);
		},

		serviceUrl: "/sap/opu/odata/sap/ZPMGW_ORDERNPM_SRV",
		serviceUrlUSER: "/sap/opu/odata/sap/Z_USER_INFO2_SRV",

		onCallReadOdataUSER: function (filters, fnVarSuccess, fnVarError) {
			var url = this.serviceUrlUSER;
			var lo_UseridFilter = new sap.ui.model.Filter({
				path: "Userid",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: filters.username
			});

			var lo_MethodFilter = new sap.ui.model.Filter({
				path: "Method",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: filters.method
			});

			var lo_ItemFilter = new sap.ui.model.Filter({
				path: "Item",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: filters.item
			});

			var filterArray = [];
			filterArray.push(lo_UseridFilter);
			filterArray.push(lo_MethodFilter);
			filterArray.push(lo_ItemFilter);

			var oModel = new sap.ui.model.odata.v2.ODataModel(url, false);

			var params = {
				context: null,
				urlParameters: {
					"$format": "json"
				},
				async: false,
				filters: filterArray,
				sorters: null,
				success: fnVarSuccess,
				error: fnVarError

			};

			oModel.read("/ZAPPFIORI_COMMSet", params);

		},

		onCallReadOdata: function (filterArray, fnVarSuccess, fnVarError) {

			var url = this.serviceUrl;

			var oModel = new sap.ui.model.odata.v2.ODataModel(url, false);

			var params = {
				context: null,
				urlParameters: {
					"$format": "json"
				},
				async: false,
				filters: filterArray,
				sorters: null,
				success: fnVarSuccess,
				error: fnVarError

			};

			oModel.read("/OrdersCollectionSet", params);

		},

		onPhotoDataSuccess: function (imageData) {
			var srcImg = "data:image/jpg;base64," + imageData;
			var oImage = '<img class="imagen" src=" ' + srcImg + '"></img>';

			var dialog = new sap.m.Dialog({
				title: 'Visualización de captura',
				type: 'Message',
				content: new sap.ui.core.HTML({
					content: oImage
				}),
				beginButton: new sap.m.Button({
					text: 'Guardar',
					press: jQuery.proxy(function () {
						var sServiceUrl = "/sap/opu/odata/sap/ZPMGW_ORDERNPM_SRV";
						var mHeader = {};
						var oModel = new sap.ui.model.odata.v2.ODataModel(sServiceUrl, false, false, false, mHeader);

						var oNombreArchivo = this.oTipoFoto;
						var mHeaders = {};
						mHeaders.orderid = this.oOrderId;
						mHeaders.doctype = "Z06";
						mHeaders.descripfile = oNombreArchivo;
						mHeaders.comp_id = oNombreArchivo;
						mHeaders.latitude = this.posy;
						mHeaders.longitude = this.posx;
						mHeaders.accept = "image/jpeg";
						mHeaders["mimetype"] = "image/jpeg";
						mHeaders["slug"] = "asd";

						oModel.setHeaders(mHeaders);
						var oModelRefresh = this.getView().getModel();

						oModel.create('/OrdersFilesCollectionSet', imageData, {
							success: function (oData, oResponse) {
								//alert('Imagen cargada correctamente.');
								oModelRefresh.refresh(true);
								sap.m.MessageToast.show("Imagen cargada correctamente.");
								dialog.close();
							},
							error: function (oData, response) {
								sap.m.MessageToast.show("Error al cargar imagen.");
								//alert('Error al cargar imagen.');
							}
						});
					}, this)
				}),
				endButton: new sap.m.Button({
					text: 'Cancel',
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();
		},

		onFail: function (message) {},

		filtrarOT: function () {
			var aFilters = [];
			var sQuery = this.getView().byId("multiInput1").getValue();
			if (sQuery && sQuery.length > 0) {
				var filters = new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter("Orderid", sap.ui.model.FilterOperator.Contains, sQuery)
					],
					and: false
				});
				aFilters.push(filters);
				var oTable = this.getView().byId("lista1");
				var binding = oTable.getBinding("items");
				binding.filter(aFilters, "Application");

				var data = oTable.getBinding("items");
				this.getView().byId("oCantidadText").setText(String(data.iLength));
				
				//KB-01
			} else {
				/////KB-01
				if(sessionStorage.listItems !== ""){
				this.getView().byId("lista1").getBinding("items").aIndices = sessionStorage.listItems.split(",");
				this.getView().byId("lista1").getBinding("items").refresh();
				this.getView().byId("oCantidadText").setText(String(this.getView().byId("lista1").getBinding("items").aIndices.length));
				sessionStorage.listItems = "";
				} else {
					var oTable = this.getView().byId("lista1");
			var binding = oTable.getBinding("items");
			binding.filter(aFilters, "Application");

			var data = oTable.getBinding("items");
			this.getView().byId("oCantidadText").setText(String(data.iLength));
				}
				/////
			}
			
			// update list binding
			// var oTable = this.getView().byId("lista1");
			// var binding = oTable.getBinding("items");
			// binding.filter(aFilters, "Application");

			// var data = oTable.getBinding("items");
			// this.getView().byId("oCantidadText").setText(String(data.iLength));
			// oData.results.length
		},

		handleIconTabBarSelect: function (oEvent) {

			var sKey = oEvent.getParameter("key");
			if (!this.oExpand) {
				if (sKey == 'test_map') {
					var dialog2 = new sap.m.BusyDialog({
						text: 'Cargando',
						showCancelButton: true
					});
					dialog2.open();
					this.oExpand = true;
					var gmap = this.byId("mapa");
					var latlng = new google.maps.LatLng(-33.4682982, -70.663372);
					var mapOptions = {
						zoom: 7,
						center: latlng,
						mapTypeId: google.maps.MapTypeId.ROADMAP,
						scrollwheel: false
					}

					var mapa_id = gmap.sId;
					var test = document.getElementById(mapa_id);
					var gm = google.maps;
					var map = new gm.Map(test, mapOptions);

					jQuery.sap.require("Lipigas_Listado_Ordenes01/js/oms");
					this._oView = this.getView();
					this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this._oView));

					var oModel = this._oComponent.getModel();
					var table = this.byId("table");
					var oBinding = table.getBinding("items");
					var markers = new Array();
					oBinding.oModel.read("/OrdersCollectionSet", {
						filters: oBinding.aFilters,
						success: function (oData, response) {

							var iw = new gm.InfoWindow();
							var oms = new OverlappingMarkerSpiderfier(map, {
								markersWontMove: true,
								markersWontHide: true
							});
							var sinGeo = [];
							var conGeo = [];
							var totalMarcas = oData.results.length;
							$.each(oData.results, function (key, value) {
								if (value.CoordenadaX == '' || value.CoordenadaY == '') {
									value.marca = true;
									sinGeo.push(value);
								} else {
									conGeo.push(value)
								}
								//var marcas = construirMarcas(value, map, oms);

								/*if (marcas != undefined)
									markers.push(marcas);*/
							});

							var markersSin = [];
							var totalSin = sinGeo.length;
							var markerSinPintar = [];
							var numSinPintar = 0;
							var totalSinPintar = 1;
							$.each(sinGeo, function (key, value) {
								var geocoder = new google.maps.Geocoder();

								geocoder.geocode({
									'address': value.DireccionFull
								}, function (results, status) {
									if (status === google.maps.GeocoderStatus.OK) {
										value.results = results;
										markersSin.push(value);
										if (totalSin == markersSin.length) {
											cargarMapa(markersSin, conGeo, map, oms, dialog2, markerSinPintar, totalMarcas);
										}
									} else if (status == google.maps.GeocoderStatus.OVER_QUERY_LIMIT) {
										markerSinPintar.push(value);
										totalSin = totalSin - 1;
									} else {
										totalSin = totalSin - 1;
									}
								});
							});

							/*var ciclo2 = window.setInterval(function() {
								//alert('Pasa por el ciclo y hay:' + markersSin.length + '/' + totalSin);
								if (totalSin == markersSin.length) {
									cargarMapa(markersSin, conGeo, map, oms, dialog2);
									window.clearInterval(ciclo2);
								} else {

									$.each(sinGeo, function(key, value) {
										//alert(value.Orderid);
										//alert(value.marca);

										var geocoder = new google.maps.Geocoder();
										if (value.marca) {
											geocoder.geocode({
												'address': value.DireccionFull
											}, function(results, status) {
												if (status === google.maps.GeocoderStatus.OK) {
													value.marca = false;
													value.results = results;
													markersSin.push(value);
													//alert('order ID:' + value.Orderid);
													
													//alert('Cantidad de MarkersSin:' + markersSin.length);
													
												} else if (status == google.maps.GeocoderStatus.OVER_QUERY_LIMIT) {
													value.marca = true;
												} else {
													console.log('Error No econtro dirección');
													totalSin = totalSin - 1;
													value.marca = false;
												}
											});
										}

									});

								}
							}, 500);*/

							var abrirNavegacion = '';

							oms.addListener('click', function (marker) {
								if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
									abrirNavegacion =
										' <p style="padding:5px;"><a style="text-decoration: none;color: white;background: rgba(54,62,67,0.96);cursor:pointer; padding: 6px; border-radius:4px; font-family: Arial,Helvetica,sans-serif;font-size: 0.875rem; " href="geo:0,0?q=' +
										marker.getPosition().lat() + ',' + marker.getPosition().lng() + '">Abrir Navegación</a></p>';
								}
								if (marker.descHTML == undefined) {
									marker.descHTML = '';
								}
								var dialog = new Dialog({
									title: 'Orden:' + marker.title,
									content: new sap.ui.core.HTML({
										content: marker.descHTML + abrirNavegacion
									}),
									beginButton: new Button({
										text: 'Close',
										press: function () {
											dialog.close();
										}
									}),

									afterClose: function () {
										dialog.destroy();
									}
								});
								dialog.addButton(new Button({
									text: "Ir a Operaciones",
									press: function () {
										var vOrderId = marker.desc.Orderid;
										var vOrderTypetxt = marker.desc.OrderTypetxt;
										var vPmacttypetxt = marker.desc.Pmacttypetxt;
										var vFuncldescr = marker.desc.Funcldescr;
										var vPrioDesc = marker.desc.PrioDesc;
										var vUStatus = marker.desc.UStatus;
										var vUStatusT = marker.desc.UStatusT;
										var vStartDate = marker.desc.StartDate;
										var vFinishDate = marker.desc.FinishDate;
										var vCoordenadaX = marker.desc.CoordenadaX;
										var vCoordenadaY = marker.desc.CoordenadaY;
										var vDireccionFull = marker.desc.DireccionFull;
										var vTelnumber = marker.desc.Telnumber;

										this.oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
										this.oCrossAppNav.toExternal({
											target: {
												semanticObject: "zpmfiodetope01Sem",
												//semanticObject: "zlipigas_operaciones",
												action: "display"
											},
											params: {
												Orderid: vOrderId,
												OrderTypetxt: vOrderTypetxt,
												Pmacttypetxt: vPmacttypetxt,
												Funcldescr: vFuncldescr,
												PrioDesc: vPrioDesc,
												UStatus: vUStatus,
												UStatusT: vUStatusT,
												StartDate: vStartDate,
												FinishDate: vFinishDate,
												CoordenadaX: vCoordenadaX,
												CoordenadaY: vCoordenadaY,
												DireccionFull: vDireccionFull,
												Telnumber: vTelnumber
											}
										});
									}
								}));
								dialog.addButton(new Button({
									text: "Mostrar Ruta",
									press: function () {
										if (navigator.geolocation) {
											var options = {
												enableHighAccuracy: true,
												timeout: 5000,
												maximumAge: 0
											};

											navigator.geolocation.getCurrentPosition(function (position) {
												var directionsService = new google.maps.DirectionsService();
												var directionsDisplay = new google.maps.DirectionsRenderer();
												var pos_origen = {
													lat: position.coords.latitude,
													lng: position.coords.longitude
												};
												var pos_destino = {
													lat: marker.getPosition().lat(),
													lng: marker.getPosition().lng()
												};

												var request = {
													origin: pos_origen,
													destination: pos_destino,
													travelMode: google.maps.DirectionsTravelMode.DRIVING
												};

												directionsService.route(request, function (response, status) {
													if (status == google.maps.DirectionsStatus.OK) {
														directionsDisplay.setMap(map);
														directionsDisplay.setDirections(response);
													} else {
														alert('Error al trazar la ruta.');
													}
												});
												dialog.close();
											}, function (error) {
												alert(error.message);
											}, options);
										} else {
											alert('Error no aguanta Geocalización.');
										}
									}
								}));
								dialog.addButton(new Button({
									text: "Cerrar",
									press: function () {
										dialog.close();
									}
								}));
								dialog.open();

							});
						},
						error: function (oData, response) {
							alert('Error en la conexión.');
						}
					});
				}
			}
		},

		consultarPuntos: function () {
			var markersSin = [];
			var totalSin = this.oMarkerSin.length;
			var conGeo = [];
			var gmap = this.byId("mapa");
			var mapa_id = gmap.sId;
			var test = document.getElementById(mapa_id);

			if (totalSin > 0) {
				var dialog2 = new sap.m.BusyDialog({
					text: 'Cargando',
					showCancelButton: true
				});
				dialog2.open();

				$.each(this.oMarkerSin, function (key, value) {
					var geocoder = new google.maps.Geocoder();
					/*var oms = new OverlappingMarkerSpiderfier(test, {
						markersWontMove: true,
						markersWontHide: true
					});*/
					geocoder.geocode({
						'address': value.DireccionFull
					}, function (results, status) {
						if (status === google.maps.GeocoderStatus.OK) {
							value.results = results;
							markersSin.push(value);
							if (totalSin == markersSin.length) {
								cargarMapa(markersSin, conGeo, test, oms, dialog2);
							}
						} else if (status == google.maps.GeocoderStatus.OVER_QUERY_LIMIT) {
							this.oMarkerSin.push(value);
							totalSin = totalSin - 1;
						} else {
							totalSin = totalSin - 1;
						}
					});

				});
			}
		},
		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happ     en if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function (oEvent) {
			// update the worklist's object counter after the table update
			var sTitle,
				oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("worklistTableTitle");
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
		},

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress: function (oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},

		/**
		 * Navigates back in the browser history, if the entry was created by this app.
		 * If not, it navigates to the Fiori Launchpad home page.
		 * @public
		 */
		onNavBack: function () {
			sessionStorage.clear();
			this.getView().byId("oUserNameText").setText('');
			history.go(-1);
		},

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function () {
			var oViewModel = this.getModel("worklistView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});
			oShareDialog.open();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showObject: function (oItem) {
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("Orderid")
			});
		},

		/**
		 * Sets the item count on the worklist view header
		 * @param {integer} iTotalItems the total number of items in the table
		 * @private
		 */
		_updateListItemCount: function (iTotalItems) {
			var sTitle;
			// only update the counter if the length is final
			if (this._oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
				this.oViewModel.setProperty("/worklistTableTitle", sTitle);
			}
		},
		changeToSingleSelectionMode: function () {
			this.oFiltroFecha = null;
			var oCalendar = this.getView().byId("selectionCalendar");
			// this._clearModel();
			oCalendar.removeAllSelectedDates();
			oCalendar.setSingleSelection(true);
			oCalendar.setIntervalSelection(false);
		},

		changeToRangeSelectionMode: function () {
			this.oFiltroFecha = null;
			var oCalendar = this.getView().byId("selectionCalendar");
			// this._clearModel();
			oCalendar.removeAllSelectedDates();
			oCalendar.setSingleSelection(true);
			oCalendar.setIntervalSelection(true);
		},

		changeToMultiSelectionMode: function () {
			this.oFiltroFecha = null;
			var oCalendar = this.getView().byId("selectionCalendar");
			//this._clearModel();
			oCalendar.removeAllSelectedDates();
			oCalendar.setSingleSelection(false);
			oCalendar.setIntervalSelection(false);
		},
		onTapOnDate: function (oEvent) {
			var oList = this.getView().byId("lista2");
			var oItem = this.getView().byId("columnListItemcal");
			//var oModel = this._oComponent.getModel();

			var oCalendar = oEvent.oSource;
			var aSelectedDates = oCalendar.getSelectedDates();

			var filters = [];
			var oDate1;
			var oDate2;

			if (aSelectedDates.length > 0) {
				if (aSelectedDates.length > 1) {
					for (var i = 0; i < aSelectedDates.length; i++) {
						oDate1 = aSelectedDates[i].getStartDate();
						var oFilter1 = new sap.ui.model.Filter("StartDate", sap.ui.model.FilterOperator.EQ, oDate1);
						filters.push(oFilter1);
					}
					this.oFiltroFecha = filters;
					this._applyFilter(this.oFiltroFecha);
				} else {
					oDate1 = aSelectedDates[0].getStartDate();
					oDate2 = aSelectedDates[0].getEndDate();
					if (oDate2 !== null) {
						var fechaFin = this.oFormatYyyymmdd.format(oDate2);
						var oFilter1 = new sap.ui.model.Filter("StartDate", sap.ui.model.FilterOperator.BT, oDate1, oDate2);
						this.oFiltroFecha = oFilter1;
					} else {
						var oFilter1 = new sap.ui.model.Filter("StartDate", sap.ui.model.FilterOperator.EQ, oDate1);
						this.oFiltroFecha = oFilter1;
					}
					this._applyFilter(this.oFiltroFecha);
				}
			}
		},
		_applyFilter: function (oFilter) {
			var oBinding = this.byId("lista1").getBinding("items");
			// Guarda facet filter en variable de sesion
			var oFacetFilter = this.byId("idFacetFilter");
			// Guarda los filtros en variable de sesion
			if (this.oFiltroLista !== null) {
				var oArrayFilterListaSup = this.oFiltroLista.aFilters;
				var jsonLista = '{"filters":[';
				for (var i = 0; i < oArrayFilterListaSup.length; i++) {
					var oArrayFilterListaInf = this.oFiltroLista.aFilters[i].aFilters;
					for (var j = 0; j < oArrayFilterListaInf.length; j++) {
						jsonLista = jsonLista +
							'{"sPath":"' + oArrayFilterListaInf[j].sPath + '",' +
							'"sOperator":"' + oArrayFilterListaInf[j].sOperator + '",' +
							'"oValue1":"' + oArrayFilterListaInf[j].oValue1 + '",' +
							'"oValue2":"' + oArrayFilterListaInf[j].oValue2 + '",' +
							'"_bMultiFilter":"' + oArrayFilterListaInf[j]._bMultiFilter + '"},';
					}
				}
				jsonLista = jsonLista.substring(0, jsonLista.length - 1) + ']}';
				sessionStorage.oFiltroLista = jsonLista;
			}
			if (this.oFiltroFecha !== null) {
				var jsonFecha = '{"filters":[';
				var oTypeFiltro = this.oFiltroFecha instanceof Array;
				if (oTypeFiltro) {
					for (var j = 0; j < this.oFiltroFecha.length; j++) {
						jsonFecha = jsonFecha +
							'{"sPath":"' + this.oFiltroFecha[j].sPath + '",' +
							'"sOperator":"' + this.oFiltroFecha[j].sOperator + '",' +
							'"oValue1":"' + this.oFiltroFecha[j].oValue1 + '",' +
							'"oValue2":"' + this.oFiltroFecha[j].oValue2 + '",' +
							'"_bMultiFilter":"' + this.oFiltroFecha[j]._bMultiFilter + '"},';
					}
					jsonFecha = jsonFecha.substring(0, jsonFecha.length - 1) + ']}';
				} else {
					jsonFecha = jsonFecha +
						'{"sPath":"' + this.oFiltroFecha.sPath + '",' +
						'"sOperator":"' + this.oFiltroFecha.sOperator + '",' +
						'"oValue1":"' + this.oFiltroFecha.oValue1 + '",' +
						'"oValue2":"' + this.oFiltroFecha.oValue2 + '",' +
						'"_bMultiFilter":"' + this.oFiltroFecha._bMultiFilter + '"}]}';
				}
				sessionStorage.oFiltroFecha = jsonFecha;
			}
			if (this.oFiltroLista !== null && this.oFiltroFecha !== null && this.oFiltroOrden != null) {
				var oFiltro = new sap.ui.model.Filter([this.oFiltroFecha, this.oFiltroLista], true);
				oBinding.filter(oFiltro);
			} else {
				if (this.oFiltroLista !== null) {
					oBinding.filter(this.oFiltroLista);
				}
				if (this.oFiltroFecha !== null) {
					oBinding.filter(this.oFiltroFecha, sap.ui.model.FilterType.Control);
				}

				if (this.oFiltroLista === null && this.oFiltroFecha === null) {
					oBinding.filter(oFilter);
				}
			}
			this._applyFilter2(oFilter);
		},
		_applyFilter2: function (oFilter) {
			var oBinding = this.byId("list").getBinding("items");
			this.oExpand = false;
			if (this.oFiltroLista !== null && this.oFiltroFecha !== null) {
				var oFiltro = new sap.ui.model.Filter([this.oFiltroFecha, this.oFiltroLista], true);
				oBinding.filter(oFiltro);
			} else {
				if (this.oFiltroLista !== null) {
					oBinding.filter(this.oFiltroLista);
					this.feedFacetFilter(oFilter);
				}
				if (this.oFiltroFecha !== null) {
					oBinding.filter(this.oFiltroFecha, sap.ui.model.FilterType.Control);
					this.feedFacetFilter(oFilter);
				}
				if (this.oFiltroLista === null && this.oFiltroFecha === null) {
					oBinding.filter(oFilter);
					this.feedFacetFilter(oFilter);
				}
			}
		},

		/****************************************************************************************/
		/****************************************************************************************/
		/****************************************************************************************/
		/****************************************************************************************/
		/****************************************************************************************/
		/****************************************************************************************/
		/****************************************************************************************/

		_applyFilter3: function (oTableSearchState) {
			var oTable = this.byId("table"),
				oViewModel = this.getModel("worklistView");
			oTable.getBinding("items").filter(oTableSearchState, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (oTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
			this.feedFacetFilter();
		},

		/****************************************************************************************/
		/****************************************************************************************/
		/****************************************************************************************/
		/****************************************************************************************/
		/****************************************************************************************/
		/****************************************************************************************/
		/****************************************************************************************/
		/****************************************************************************************/

		// --- Navigation
		onLineItemPressed: function (oEvent) {
			/*			this._oRouter.navTo("details", {
				from: "main",
				entity: oEvent.getSource().getBindingContext().getPath().substr(1),
				tab: null
			});*/

			//aqui

			///////////////////////////////// KB-01
			sessionStorage.listItems = oEvent.getSource().getParent().getBinding("items").aIndices.join();
			/////////////////////////////////

			var date1 = this.getView().byId("__picker0").getValue();
			var date2 = this.getView().byId("__picker1").getValue();
			var searchFieldValue = this.getView().byId("multiInput1").getValue();

			var searchJson = {
				date1: date1,
				date2: date2,
				searchfield: searchFieldValue
			};
			sessionStorage.setItem("search", JSON.stringify(searchJson));
			var oTable = this.byId("lista1");
			var sPath = oEvent.getSource().getBindingContext().getPath();
			var oModel = oTable.getModel();
			var oData = oModel.getProperty(sPath);

			var vOrderId = oData['Orderid'];
			var vOrderTypetxt = oData['OrderTypetxt'];
			var vPmacttypetxt = oData['Pmacttypetxt'];
			var vFuncldescr = oData['Funcldescr'];
			var vPrioDesc = oData['PrioDesc'];
			var vUStatus = oData['UStatus'];
			var vUStatusT = oData['UStatusT'];
			var vStartDate = oData['StartDate'];
			var vFinishDate = oData['FinishDate'];
			var vCoordenadaX = oData['CoordenadaX'];
			var vCoordenadaY = oData['CoordenadaY'];
			var vDireccionFull = oData['DireccionFull'];
			var vTelnumber = oData['Telnumber'];
			var vEQUNR = oData['Equnr'];
			var vEQKTX = oData['Eqktx'];
			var vTPLNR = oData['Tplnr'];

			/*	var vEQUNR = oData['EQUNR'];
				var vEQKTX = oData['EQKTX'];
				var vTPLNR = oData['TPLNR'];*/

			this.oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
			this.oCrossAppNav.toExternal({
				target: {
					semanticObject: "zpmfiodetope01Sem",
					//semanticObject: "zlipigas_operaciones",
					action: "display"
				},
				params: {
					Orderid: vOrderId,
					//OrderType: vOrderType,
					OrderTypetxt: vOrderTypetxt,
					//Pmacttype: vPmacttype,
					Pmacttypetxt: vPmacttypetxt,
					Funcldescr: vFuncldescr,
					PrioDesc: vPrioDesc,
					UStatus: vUStatus,
					UStatusT: vUStatusT,
					StartDate: vStartDate,
					FinishDate: vFinishDate,
					CoordenadaX: vCoordenadaX,
					CoordenadaY: vCoordenadaY,
					DireccionFull: vDireccionFull,
					Telnumber: vTelnumber,
					Equnr: vEQUNR,
					Eqktx: vEQKTX,
					Tplnr: vTPLNR
				}
			});
		},

		onLineItemPressed2: function (oEvent) {
			var oTable = this.byId("lista2");
			var sPath = oEvent.getSource().getBindingContext().getPath();
			var oModel = oTable.getModel();
			var oData = oModel.getProperty(sPath);

			var vOrderId = oData['Orderid'];
			//var vOrderType		= oData['OrderType'];
			var vOrderTypetxt = oData['OrderTypetxt'];
			//var vPmacttype		= oData['Pmacttype'];
			var vPmacttypetxt = oData['Pmacttypetxt'];
			var vFuncldescr = oData['Funcldescr'];
			var vPrioDesc = oData['PrioDesc'];
			var vUStatus = oData['UStatus'];
			var vUStatusT = oData['UStatusT'];
			var vStartDate = oData['StartDate'];
			var vFinishDate = oData['FinishDate'];
			var vCoordenadaX = oData['CoordenadaX'];
			var vCoordenadaY = oData['CoordenadaY'];
			var vDireccionFull = oData['DireccionFull'];
			var vTelnumber = oData['Telnumber'];
			var vEQUNR = oData['Equnr'];
			var vEQKTX = oData['Eqktx'];
			var vTPLNR = oData['Tplnr'];

			/*	var vEQUNR = oData['EQUNR'];
				var vEQKTX = oData['EQKTX'];
				var vTPLNR = oData['TPLNR'];*/

			this.oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
			this.oCrossAppNav.toExternal({
				target: {
					semanticObject: "zpmfiodetope01Sem",
					//semanticObject: "zlipigas_operaciones",
					action: "display"
				},
				params: {
					Orderid: vOrderId,
					//OrderType: vOrderType,
					OrderTypetxt: vOrderTypetxt,
					//Pmacttype: vPmacttype,
					Pmacttypetxt: vPmacttypetxt,
					Funcldescr: vFuncldescr,
					PrioDesc: vPrioDesc,
					UStatus: vUStatus,
					UStatusT: vUStatusT,
					StartDate: vStartDate,
					FinishDate: vFinishDate,
					CoordenadaX: vCoordenadaX,
					CoordenadaY: vCoordenadaY,
					DireccionFull: vDireccionFull,
					Telnumber: vTelnumber,
					Equnr: vEQUNR,
					Eqktx: vEQKTX,
					Tplnr: vTPLNR
				}
			});
		},
		changeDate: function (oEvent) {
			var oDate0 = this.byId("__picker0");
			var oDate1 = this.byId("__picker1");

			var fecha0 = oDate0.getDateValue();
			var fecha1 = oDate1.getDateValue();

			var that = this;

			var arrayDATA = [];
			var filterArray = [];

			if (fecha0 !== null && fecha1 !== null) {
				if (fecha0 > fecha1) {
					var msg = 'Fecha DESDE no debe ser mayor a fecha HASTA';
					sap.m.MessageToast.show(msg);
					return false;
				} else {

					var oFilterDate = new sap.ui.model.Filter({
						path: "StartDate",
						operator: sap.ui.model.FilterOperator.BT,
						value1: fecha0,
						value2: fecha1
					});

					var model = sap.ui.getCore().getModel("oModelParamUser").getData();

					filterArray.push(oFilterDate);
					var oFilterUser = new sap.ui.model.Filter({
						path: "IUname",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: model.user
					});
					filterArray.push(oFilterUser);
				}
			} else {
				var msg = 'Indicar rango de fechas DESDE - HASTA';
				sap.m.MessageToast.show(msg);
				return false;
			}

			that.setBusyById("lista1", true);

			var list = that.getView().byId("lista1");

			var fnVarSuccess = function (oData, response) {

				if (oData.results.length == 0) {
					sap.m.MessageToast.show("No se han encontrado ordenes de mantenimiento...");
					list.setModel(null);
					that.setBusyById("lista1", false);
					that.getView().byId("oCantidadText").setText('');
					return false;
				}
				list.setModel(null);
				that.setBusyById("lista1", false);
				for (var i = 0; i < oData.results.length; i++) {
					arrayDATA.push(oData.results[i]);
				}

				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData(arrayDATA);

				list.setModel(oModel);

				that.getView().byId("oCantidadText").setText(oData.results.length);
				that.feedFacetFilter(arrayDATA);
				if (sessionStorage.search !== undefined) {
					var searchValues = JSON.parse(sessionStorage.search);
					that.getView().byId("multiInput1").setValue(searchValues.searchfield);
					that.filtrarOT();
				}
			};
			var fnVarError = function (err) {
				that.setBusyById("lista1", false);
			};

			that.onCallReadOdata(filterArray, fnVarSuccess, fnVarError);
		},

		RestartDISP: function (oEvent) {
			this.setBusyById("lista1", true);
			setTimeout(function () {
				console.log("Here goes nothing.");
			}, 500);
			var that = this;
			var oFacetFilter = sap.ui.getCore().byId(oEvent.getParameter("id"));
			var aFacetFilterLists = oFacetFilter.getLists();
			for (var i = 0; i < aFacetFilterLists.length; i++) {
				for (var i = 0; i < aFacetFilterLists.length; i++) {
					aFacetFilterLists[i].setSelectedKeys();
				}
			}
			var oTable = this.getView().byId("lista1");
			var binding = oTable.getBinding("items");
			binding.filter(null, "Application");

			var oDate0 = this.byId("__picker0");
			var oDate1 = this.byId("__picker1");

			oDate0.setValue("");
			oDate1.setValue("");

			var arrayDATA = [];
			var filterArray = [];

			var model = sap.ui.getCore().getModel("oModelParamUser").getData();
			var oFilterUser = new sap.ui.model.Filter({
				path: "IUname",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: model.user
			});
			filterArray.push(oFilterUser);

			var list = that.getView().byId("lista1");

			var fnVarSuccess = function (oData, response) {

				if (oData.results.length == 0) {
					sap.m.MessageToast.show("No se a encontrado ordenes de mantenimiento...");
					that.getView().byId("oCantidadText").setText('');
					that.setBusyById("lista1", false);
					list.setModel(null);
					return false;

				}

				for (var i = 0; i < oData.results.length; i++) {
					arrayDATA.push(oData.results[i]);
				}
				that.setBusyById("lista1", false);
				list.setModel(null);
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData(arrayDATA);
				list.setModel(oModel);
				that.getView().byId("oCantidadText").setText(oData.results.length);
				that.feedFacetFilter(arrayDATA);
			};

			var fnVarError = function (err) {
				that.setBusyById("lista1", false);
			};

			that.onCallReadOdata(filterArray, fnVarSuccess, fnVarError);
		},

		feedObjectStatus: function () {

			var oTabla = this.byId("table");
			var oColumna = this.byId("columnListItem");

			var oStatus = new sap.m.ObjectStatus("columnListItem", {
				text: "{UStatusT}",
				icon: {
					path: 'UStatus',
					formatter: function (oStatus) {
						switch (oStatus) {
						case "DISP":
							return "sap-icon://status-completed";
						case "ENEJ":
							return "sap-icon://status-completed";
						case "EJEC":
							return "sap-icon://status-completed";

						case "FINA":
							return "sap-icon://status-completed";
						case "APRO":
							return "sap-icon://status-completed";

						case "REPR":
							return "sap-icon://status-completed";
						case "REVI":
							return "sap-icon://status-completed";
						}
					}
				}
			});

			oColumna.insertCell(oStatus, 6);

			oTabla.onAfterRendering = function () {
				if (sap.m.Table.prototype.onAfterRendering) {
					sap.m.Table.prototype.onAfterRendering.apply(this, arguments);
				}
				var items = this.getItems();
				for (var i = 0; i < items.length; i++) {
					var item = items[i];
					var obj = item.getBindingContext().getObject();
					switch (obj.UStatus) {
					case "DISP":
						var oIcon = item.$().find('.sapUiIcon');
						oIcon.addClass('greenIcon');
						break;
					case "ENEJ":
						var oIcon = item.$().find('.sapUiIcon');
						oIcon.addClass('yellowIcon');
						break;
					case "EJEC":
						var oIcon = item.$().find('.sapUiIcon');
						oIcon.addClass('blueIcon');
						break;

					case "FINA":
						var oIcon = item.$().find('.sapUiIcon');
						oIcon.addClass('brownIcon');
						break;
					case "APRO":
						var oIcon = item.$().find('.sapUiIcon');
						oIcon.addClass('grayIcon');
						break;

					case "REPR":
						var oIcon = item.$().find('.sapUiIcon');
						oIcon.addClass('redIcon');
						break;
					case "REVI":
						var oIcon = item.$().find('.sapUiIcon');
						oIcon.addClass('orangeIcon');
						break;
					}
				}
			};
		},
		feedObjectStatus1: function () {

			var oLista = this.byId("list");
			var oCampo = this.byId("mainListItem");

			var oStatus = new sap.m.ObjectStatus("mainListItem", {
				text: "{UStatusT}",
				icon: {
					path: 'UStatus',
					formatter: function (oStatus) {
						switch (oStatus) {
						case "DISP":
							return "sap-icon://status-completed";
						case "ENEJ":
							return "sap-icon://status-completed";
						case "EJEC":
							return "sap-icon://status-completed";

						case "FINA":
							return "sap-icon://status-completed";
						case "APRO":
							return "sap-icon://status-completed";

						case "REPR":
							return "sap-icon://status-completed";
						case "REVI":
							return "sap-icon://status-completed";
						}
					}
				}
			});

			oCampo.setFirstStatus(oStatus);

			oLista.onAfterRendering = function () {
				if (sap.m.List.prototype.onAfterRendering) {
					sap.m.List.prototype.onAfterRendering.apply(this, arguments);
				}
				var items = this.getItems();
				for (var i = 0; i < items.length; i++) {
					var item = items[i];
					var obj = item.getBindingContext().getObject();
					switch (obj.UStatus) {
					case "DISP":
						var oIcon = item.$().find('.sapUiIcon');
						oIcon.addClass('greenIcon');
						break;
					case "ENEJ":
						var oIcon = item.$().find('.sapUiIcon');
						oIcon.addClass('yellowIcon');
						break;
					case "EJEC":
						var oIcon = item.$().find('.sapUiIcon');
						oIcon.addClass('blueIcon');
						break;

					case "FINA":
						var oIcon = item.$().find('.sapUiIcon');
						oIcon.addClass('brownIcon');
						break;
					case "APRO":
						var oIcon = item.$().find('.sapUiIcon');
						oIcon.addClass('grayIcon');
						break;

					case "REPR":
						var oIcon = item.$().find('.sapUiIcon');
						oIcon.addClass('redIcon');
						break;
					case "REVI":
						var oIcon = item.$().find('.sapUiIcon');
						oIcon.addClass('orangeIcon');
						break;
					}
				}
			};
		},
		handleFacetFilterReset: function (oEvent) {
			var oFacetFilter = sap.ui.getCore().byId(oEvent.getParameter("id"));
			var aFacetFilterLists = oFacetFilter.getLists();
			for (var i = 0; i < aFacetFilterLists.length; i++) {
				for (var i = 0; i < aFacetFilterLists.length; i++) {
					aFacetFilterLists[i].setSelectedKeys();
				}
			}

			var oDate0 = this.byId("__picker0");
			var oDate1 = this.byId("__picker1");

			oDate0.setValue();
			oDate1.setValue();

			this.oFiltroFecha = null;
			this.oFiltroLista = null;

			//this.oFiltroGlobal = [];

			this._applyFilter([]);
		},

		handleListClose: function (oEvent) {
			var aFilters = [];
			var sQuery = this.getView().byId("multiInput1").getValue();
			if (sQuery !== "" || sQuery !== null) {
				if (sQuery && sQuery.length > 0) {
					var filters = new sap.ui.model.Filter({
						filters: [
							new sap.ui.model.Filter("Orderid", sap.ui.model.FilterOperator.Contains, sQuery)
						],
						and: false
					});
					aFilters.push(filters);
				}
			}

			// Get the Facet Filter lists and construct a (nested) filter for the binding
			var oFacetFilter = oEvent.getSource().getParent();
			var mFacetFilterLists = oFacetFilter.getLists().filter(function (oList) {
				return oList.getActive() && oList.getSelectedItems().length;
			});

			var oTable = this.getView().byId("lista1");
			var binding = oTable.getBinding("items");
			// Build the nested filter with ORs between the values of each group and
			// ANDs between each group
			if (mFacetFilterLists.length == 0) {
				binding.filter(null, "Application");
				return '';
			}
			var okeyList = mFacetFilterLists.map(function (oList) {
				return oList.getKey();
			});

			var okeyItem = mFacetFilterLists.map(function (oList) {
				return oList.getSelectedItems().map(function (oItem) {
					return oItem.getKey();
				});
			});
			for (var i = 0; i < okeyList.length; i++) {
				var keyList = okeyList[i];
				for (var j = 0; j < okeyItem.length; j++) {
					for (var o = 0; o < okeyItem[j].length; o++) {
						var tempKeys = okeyItem[j];
						var keyItem = tempKeys[o];
						var filtersByList = new sap.ui.model.Filter({
							path: keyList,
							operator: sap.ui.model.FilterOperator.EQ,
							value1: tempKeys[o]
						});
						aFilters.push(filtersByList);
					}
				}
			}

			// aFilters.push(oFilter);
			binding.filter(null, "Application");
			binding.filter(aFilters, "Application");
			var data = oTable.getBinding("items");
			this.getView().byId("oCantidadText").setText(String(data.iLength));
		},
		feedFacetFilter: function (oFilter) {

			var facetFilter = this.byId("idFacetFilter");
			var facetFilterList1 = this.byId("idFacetFilterList_1"); //Prioridad
			var facetFilterList2 = this.byId("idFacetFilterList_2"); //ORDEN
			var facetFilterList3 = this.byId("idFacetFilterList_3"); //Clase Actividad
			var facetFilterList4 = this.byId("idFacetFilterList_4"); //Status usuario
			var facetFilterList5 = this.byId("idFacetFilterList_5"); //Centro

			facetFilterList1.removeAllItems();
			facetFilterList2.removeAllItems();
			facetFilterList3.removeAllItems();
			facetFilterList4.removeAllItems();
			facetFilterList5.removeAllItems();

			var result = oFilter;
			var filter1 = new Array();
			var filter2 = new Array();
			var filter3 = new Array();
			var filter4 = new Array();
			var filter5 = new Array();
			var filterAux1 = {
				priority: [],
				orden: [],
				clase: [],
				status: [],
				centro: []
			};
			if (result.length == 0) {
				return false;
			}

			jQuery.each(result, function (key, value) {
				var existePrioridad = filter1.indexOf(value.PrioDesc);
				if (existePrioridad === -1 && value.PrioDesc !== '') {
					var objPriority = {
						"PrioDesc": value.PrioDesc,
						"Priority": value.Priority
					};
					filter1.push(value.PrioDesc);
					filterAux1.priority.push(objPriority);
				}

				var orden = value.OrderTypetxt;
				var existeOrden = filter2.indexOf(orden);
				if (existeOrden === -1 && orden !== '') {
					var objOrden = {
						"OrderType": orden,
						"OrderTypetxt": value.OrderType
					};
					filter2.push(orden);
					filterAux1.orden.push(objOrden);
				}

				var existeClase = filter3.indexOf(value.Pmacttypetxt);
				if (existeClase === -1 && value.Pmacttypetxt !== '') {
					var objClase = {
						"Pmacttypetxt": value.Pmacttypetxt,
						"Pmacttype": value.Pmacttype
					};
					filter3.push(value.Pmacttypetxt);
					filterAux1.clase.push(objClase);
				}

				var existeStatus = filter4.indexOf(value.UStatusT);
				if (existeStatus === -1 && value.UStatusT !== '') {
					var objStatus = {
						"UStatusT": value.UStatusT,
						"UStatus": value.UStatus
					};
					filter4.push(value.UStatusT);
					filterAux1.status.push(objStatus);
				}
				//Centro
				var planta = value.Plant;
				var existePlanta = filter5.indexOf(planta);
				if (existePlanta === -1 && orden !== '') {
					var objPlanta = {
						"Plant": planta
					};
					filter5.push(planta);
					filterAux1.centro.push(objPlanta);
				}
			});

			//Cargar los filtros
			var oFiltros = {
				'Priority': filterAux1.priority,
				"orden": filterAux1.orden,
				"clase": filterAux1.clase,
				'status': filterAux1.status,
				'centro': filterAux1.centro
			};

			var model = new sap.ui.model.json.JSONModel(oFiltros);

			facetFilter.setModel(model);
			facetFilterList1.setModel(model);
			facetFilterList2.setModel(model);
			facetFilterList3.setModel(model);
			facetFilterList4.setModel(model);
			facetFilterList5.setModel(model);

			var oItem1 = new sap.m.FacetFilterItem({
				key: "{Priority}",
				text: "{PrioDesc}"
			});
			facetFilterList1.bindItems("/Priority", oItem1);

			var oItem2 = new sap.m.FacetFilterItem({
				key: "{OrderType}",
				text: "{OrderTypetxt}"
			});
			facetFilterList2.bindItems("/orden", oItem2);

			var oItem3 = new sap.m.FacetFilterItem({
				key: "{Pmacttype}",
				text: "{Pmacttypetxt}"
			});
			facetFilterList3.bindItems("/clase", oItem3);

			var oItem4 = new sap.m.FacetFilterItem({
				key: "{UStatus}",
				text: "{UStatusT}"
			});
			facetFilterList4.bindItems("/status", oItem4);

			var oItem5 = new sap.m.FacetFilterItem({
				key: "{Plant}",
				text: "{Plant}"
			});
			facetFilterList5.bindItems("/centro", oItem5);
		},
		feedObjectStatus2: function () {

			var oTabla = this.byId("table");
			var oColumna = this.byId("columnListItem");

			var oStatus = new sap.m.ObjectStatus("columnListItem", {
				text: "{UStatusT}"
			});

			var oIcon = new sap.ui.core.Icon({
				src: 'sap-icon://status-completed',
				color: {
					path: 'UStatus',
					formatter: function (oStatus) {
						switch (oStatus) {
						case "DISP":
							return "#1EFF24";
						case "ENEJ":
							return "#FFFC19";
						case "EJEC":
							return "#1485CC";

						case "FINA":
							return "#B25A12";
						case "APRO":
							return "#C8CBFF";

						case "REPR":
							return "#FF0000";
						case "REVI":
							return "#FF9C15";
						}
					}
				}
			});

			oColumna.insertCell(oIcon, 6);
			oColumna.insertCell(oStatus, 7);

			var oExtra001 = new sap.m.Text("extra001_cell", {
				text: "{OrderType}"
			});
			oColumna.insertCell(oExtra001, 8);

			var oExtra002 = new sap.m.Text("extra002_cell", {
				text: "{OrderTypetxt}"
			});
			oColumna.insertCell(oExtra002, 9);

			var oExtra003 = new sap.m.Text("extra003_cell", {
				text: "{DireccionFull}"
			});
			oColumna.insertCell(oExtra003, 10);

			var oExtra004 = new sap.m.Text("extra004_cell", {
				text: "{Telnumber}"
			});
			oColumna.insertCell(oExtra004, 11);

			var oExtra005 = new sap.m.Text("extra005_cell", {
				text: "{Canal}"
			});
			oColumna.insertCell(oExtra005, 12);

			var oExtra006 = new sap.m.Text("extra006_cell", {
				text: "{SStatus}"
			});
			oColumna.insertCell(oExtra006, 13);

			var oExtra007 = new sap.m.Text("extra007_cell", {
				text: "{Pmacttype}"
			});
			oColumna.insertCell(oExtra007, 14);

			var oExtra008 = new sap.m.Text("extra008_cell", {
				text: "{Pmacttypetxt}"
			});
			oColumna.insertCell(oExtra008, 15);

			var oExtra009 = new sap.m.Text("extra009_cell", {
				text: "{Priority}"
			});
			oColumna.insertCell(oExtra009, 16);

			var oExtra010 = new sap.m.Text("extra010_cell", {
				text: "{PrioDesc}"
			});
			oColumna.insertCell(oExtra010, 17);

			var oExtra011 = new sap.m.Text("extra011_cell", {
				text: "{WorkCntr}"
			});
			oColumna.insertCell(oExtra011, 18);

			var oExtra012 = new sap.m.Text("extra012_cell", {
				text: "{Plant}"
			});
			oColumna.insertCell(oExtra012, 19);

			var oExtra013 = new sap.m.Text("extra013_cell", {
				text: "{Comuna}"
			});
			oColumna.insertCell(oExtra013, 20);
		},
		feedObjectStatus3: function () {

			var oTabla = this.byId("list");
			var oColumna = this.byId("columnListItemcal");

			var oStatus = new sap.m.ObjectStatus("columnListItemcal", {
				text: "{UStatusT}"
			});

			var oIcon = new sap.ui.core.Icon({
				src: 'sap-icon://status-completed',
				color: {
					path: 'UStatus',
					formatter: function (oStatus) {
						switch (oStatus) {
						case "DISP":
							return "#1EFF24";
						case "ENEJ":
							return "#FFFC19";
						case "EJEC":
							return "#1485CC";

						case "FINA":
							return "#B25A12";
						case "APRO":
							return "#C8CBFF";

						case "REPR":
							return "#FF0000";
						case "REVI":
							return "#FF9C15";
						}
					}
				}
			});

			oColumna.insertCell(oIcon, 3);
			oColumna.insertCell(oStatus, 4);
		},

		handleSelectionChange: function () {
			var oListaCampos = this.byId("MultiID");
			var oSeleccion = oListaCampos.getSelectedKeys();

			var oTable = this.byId("table");
			var oColumns = oTable.getColumns();

			oTable.onAfterRendering = function () {
				oColumns[1].setVisible("false");
			};
		},
		feedTablePersonalization: function () {
			var oTable = this.byId("lista1");

			this.oTPerso = new TablePersoController({
				table: oTable,
				componentName: "demoApp",
				persoService: DemoPersoService
			}).activate();
		},
		onPersoButtonPressed: function (oEvent) {
			this.oTPerso.openDialog();
		},
		formatoFechaInicio: function (oDate) {
			return oDate.substring(0);
		},
		formatoFechaFin: function (oDate) {
			return oDate.substring(0);
		},

		/*CONTROLADORES GLOBALES DE APLICACIÓN*/
		addHistoryEntry: (function () {
			var aHistoryEntries = [];

			return function (oEntry, bReset) {
				if (bReset) {
					aHistoryEntries = [];
				}

				var bInHistory = aHistoryEntries.some(function (entry) {
					return entry.intent === oEntry.intent;
				});

				if (!bInHistory) {
					aHistoryEntries.push(oEntry);
					this.getOwnerComponent().getService("ShellUIService").then(function (oService) {
						oService.setHierarchy(aHistoryEntries);
					});
				}
			};
		}),

		setBusyById: function (id, state) {
			var oControl = this.getNoMatterWhat(id);
			var isOk = false;
			if (typeof oControl !== "undefined") {
				oControl.setBusy(state);
				isOk = true;
			}
			return isOk;
		},

		getNoMatterWhat: function (id) {
			var oControl = this.getView().byId(id);
			if (typeof oControl !== "undefined") {
				oControl.setVisible(true);
			} else {
				oControl = sap.ui.getCore().byId(id);
				if (typeof oControl !== "undefined") {
					oControl.setVisible(true);
				}
			}
			return oControl;
		},
		onMemory: null,
		onMemoryUser: null,
		onMemoryUserAuthorizations: null,
		onMemoryInit: false,
		/**
			MEMORIA FIN
		**/
		onGetUser: function () {
			var that = this;
			var userModel = null;
			if ((typeof sap.ui.getCore().getModel("userapi")) === "undefined") {
				userModel = new sap.ui.model.json.JSONModel();
				userModel.loadData("/services/userapi/currentUser");
				sap.ui.getCore().setModel(userModel, "userapi");
				this.onMemoryUser = userModel;
			}
		}

	});
});