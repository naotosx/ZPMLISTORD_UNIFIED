sap.ui.define(['jquery.sap.global'],
	function (jQuery) {
		"use strict";

		// Very simple page-context personalization
		// persistence service, not for productive use!
		var DemoPersoService = {

			oData: {
				_persoSchemaVersion: "1.0",
				aColumns: [{
					id: "demoApp-table-catalogTable_col1",
					order: 0,
					text: "Order ID",
					visible: true
				}, {
					id: "demoApp-table-catalogTable_col7",
					order: 1,
					text: "Fecha Inicio",
					visible: true
				}, {
					id: "demoApp-table-catalogTable_col8",
					order: 2,
					text: "Fecha Fin",
					visible: false
				}, {
					id: "demoApp-table-catalogTable_col4",
					order: 3,
					text: "Desc.",
					visible: true
				}, {
					id: "demoApp-table-catalogTable_col2",
					order: 4,
					text: "Ubicación Técnica",
					visible: true
				}, {
					id: "demoApp-table-catalogTable_col10",
					order: 5,
					text: "Icon",
					visible: true
				}, {
					id: "demoApp-table-catalogTable_col9",
					order: 6,
					text: "Status Usuario",
					visible: true
				}, {
					id: "demoApp-table-extra001",
					order: 7,
					text: "Clase de Orden",
					visible: false
				}, {
					id: "demoApp-table-extra002",
					order: 8,
					text: "Clase de Orden",
					visible: false
				}, {
					id: "demoApp-table-extra003",
					order: 9,
					text: "Dirección",
					visible: false
				}, {
					id: "demoApp-table-extra004",
					order: 10,
					text: "Telf.",
					visible: false
				}, {
					id: "demoApp-table-extra005",
					order: 11,
					text: "Canal",
					visible: false
				}, {
					id: "demoApp-table-extra006",
					order: 12,
					text: "Status Sistema",
					visible: false
				}, {
					id: "demoApp-table-extra007",
					order: 13,
					text: "Clase Actividad",
					visible: false
				}, {
					id: "demoApp-table-extra008",
					order: 14,
					text: "Desc. Clase Actividad",
					visible: false
				}, {
					id: "demoApp-table-extra009",
					order: 15,
					text: "Prioridad",
					visible: false
				}, {
					id: "demoApp-table-extra010",
					order: 16,
					text: "Desc. Prioridad",
					visible: false
				}, {
					id: "demoApp-table-extra011",
					order: 17,
					text: "Puesto de Trabajo",
					visible: false
				}, {
					id: "demoApp-table-extra012",
					order: 18,
					text: "Centro",
					visible: false
				}]
			},

			getPersData: function () {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					this._oBundle = this.oData;
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},

			setPersData: function (oBundle) {
				var oDeferred = new jQuery.Deferred();
				this._oBundle = oBundle;
				oDeferred.resolve();
				return oDeferred.promise();
			},

			resetPersData: function () {
				var oDeferred = new jQuery.Deferred();
				var oInitialData = {
					_persoSchemaVersion: "1.0",
					aColumns: [{
						id: "demoApp-table-catalogTable_col1",
						order: 0,
						text: "Order ID",
						visible: true
					}, {
						id: "demoApp-table-catalogTable_col7",
						order: 1,
						text: "Fecha Inicio",
						visible: true
					}, {
						id: "demoApp-table-catalogTable_col8",
						order: 2,
						text: "Fecha Fin",
						visible: false
					}, {
						id: "demoApp-table-catalogTable_col4",
						order: 3,
						text: "Desc.",
						visible: true
					}, {
						id: "demoApp-table-catalogTable_col2",
						order: 4,
						text: "Ubicación Técnica",
						visible: true
					}, {
						id: "demoApp-table-catalogTable_col10",
						order: 5,
						text: "Icon",
						visible: true
					}, {
						id: "demoApp-table-catalogTable_col9",
						order: 6,
						text: "Status Usuario",
						visible: true
					}, {
						id: "demoApp-table-extra001",
						order: 7,
						text: "Clase de Orden",
						visible: false
					}, {
						id: "demoApp-table-extra002",
						order: 8,
						text: "Clase de Orden",
						visible: false
					}, {
						id: "demoApp-table-extra003",
						order: 9,
						text: "Dirección",
						visible: false
					}, {
						id: "demoApp-table-extra004",
						order: 10,
						text: "Telf.",
						visible: false
					}, {
						id: "demoApp-table-extra005",
						order: 11,
						text: "Canal",
						visible: false
					}, {
						id: "demoApp-table-extra006",
						order: 12,
						text: "Status Sistema",
						visible: false
					}, {
						id: "demoApp-table-extra007",
						order: 13,
						text: "Clase Actividad",
						visible: false
					}, {
						id: "demoApp-table-extra008",
						order: 14,
						text: "Desc. Clase Actividad",
						visible: false
					}, {
						id: "demoApp-table-extra011",
						order: 17,
						text: "Puesto de Trabajo",
						visible: false
					}, {
						id: "demoApp-table-extra012",
						order: 18,
						text: "Centro",
						visible: false
					}]
				};

				//set personalization
				this._oBundle = oInitialData;

				//reset personalization, i.e. display table as defined
				//		this._oBundle = null;

				oDeferred.resolve();
				return oDeferred.promise();
			},

			//this caption callback will modify the TablePersoDialog' entry for the 'Weight' column
			//to 'Weight (Important!)', but will leave all other column names as they are.
			getCaption: function (oColumn) {
				if (oColumn.getHeader() && oColumn.getHeader().getText) {
					if (oColumn.getHeader().getText() === "Weight") {
						return "Weight (Important!)";
					}
				}
				return null;
			},

			getGroup: function (oColumn) {
				if (oColumn.getId().indexOf('productCol') != -1 ||
					oColumn.getId().indexOf('supplierCol') != -1) {
					return "Primary Group";
				}
				return "Secondary Group";
			}
		};

		return DemoPersoService;

	}, /* bExport= */ true);