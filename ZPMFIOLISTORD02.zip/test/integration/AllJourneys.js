/* global QUnit*/

sap.ui.define([
	"sap/ui/test/Opa5",
	"zpmfiolistord02/lipigas/zpmfiolistord02/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"zpmfiolistord02/lipigas/zpmfiolistord02/test/integration/pages/inicio",
	"zpmfiolistord02/lipigas/zpmfiolistord02/test/integration/navigationJourney"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "zpmfiolistord02.lipigas.zpmfiolistord02.view.",
		autoWait: true
	});
});