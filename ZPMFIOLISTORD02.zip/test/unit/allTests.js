sap.ui.define([
	"zpmfiolistord02/lipigas/zpmfiolistord02/test/unit/controller/inicio.controller"
], function () {
	"use strict";
});