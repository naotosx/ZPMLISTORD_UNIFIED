sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"zpmfiolistord02/lipigas/zpmfiolistord02/model/models"
], function (UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("zpmfiolistord02.lipigas.zpmfiolistord02.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// create and set the ODataModel
			var oModel = models.createODataModel({
				urlParametersForEveryRequest: [
					"sap-server",
					"sap-client",
					"sap-language"
				],
				url: "/sap/opu/odata/sap/ZPMGW_ORDERNPM_SRV/",
				config: {
					metadataUrlParams: {
						"sap-documentation": "heading"
					}
				}
			});
			this.setModel(oModel);
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);
			// set the device model
			this.setModel(models.createDeviceModel(), "device");
		}
	});
});